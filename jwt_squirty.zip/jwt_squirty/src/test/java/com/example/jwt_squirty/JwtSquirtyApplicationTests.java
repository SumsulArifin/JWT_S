package com.example.jwt_squirty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtSquirtyApplicationTests {

	@Test
	void contextLoads() {
	}

}
